# Understanding the System

**Explanations** help you understand the **why** and **how** of the workspace.

## What's in This Section

These documents explain **concepts and design decisions**. They're for when you want to understand how something works, not just how to use it.

### Core Concepts

**[Session Management Explained](session-management.md)**
- What sessions are and why they exist
- Session lifecycle from creation to closeout
- How sessions organize your work
- Integration with agents and memory

**[File Routing Explained](file-routing.md)**
- How files are automatically organized
- Type-based routing rules
- Why file routing matters
- Exceptions and edge cases

**[Workspace Architecture Explained](workspace-architecture.md)**
- What claude-flow+ is (stock + 2% custom)
- Stock vs custom breakdown
- Design philosophy and principles
- When to choose what approach

## Diátaxis Framework

**Explanations** are one of four documentation types:

```
Explanations ← You are here
    ↓
Understanding-oriented
    ↓
Theoretical knowledge
    ↓
Background and context
```

**Different from**:
- **Tutorials** - Learning by doing (step-by-step lessons)
- **How-to Guides** - Solving specific problems (recipes)
- **Reference** - Looking up information (quick facts)
- **Internals** - Deep technical details (system mechanics)

## When to Read These

**Read explanations when**:
- You want to understand the big picture
- You're curious about design decisions
- You need context for troubleshooting
- You're extending the system
- You want to know "why not just X?"

**Skip to other sections when**:
- You just want to get started → [Tutorials](../tutorials/)
- You have a specific task → [How-to Guides](../guides/how-to/)
- You need quick facts → [Reference](../guides/reference/)
- You're debugging internals → [System Internals](../internals/system/)

## Navigation

### By Topic

| Topic | Explanation | How-To | Internals |
|-------|-------------|---------|-----------|
| **Sessions** | [Session Management](session-management.md) | *(future)* | [Session Lifecycle](../internals/system/session-lifecycle.md) |
| **File Organization** | [File Routing](file-routing.md) | *(future)* | [Data Flow](../internals/system/data-flow.md) |
| **Architecture** | [Workspace Architecture](workspace-architecture.md) | *(future)* | [Architecture Overview](../internals/system/architecture-overview.md) |

### By Learning Goal

**I want to understand...**
- How sessions work → [Session Management](session-management.md)
- Where files go → [File Routing](file-routing.md)
- What's stock vs custom → [Workspace Architecture](workspace-architecture.md)
- How agents coordinate → [Coordination Mechanics (Internals)](../internals/system/coordination-mechanics.md)
- How memory works → [Memory Architecture (Internals)](../internals/system/memory-architecture.md)

## Complementary Documentation

### For Hands-On Learning
See: [Tutorials](../tutorials/) (when available)

### For Specific Tasks
See: [How-to Guides](../guides/how-to/)

### For Quick Lookups
See: [Reference Guides](../guides/reference/)

### For System Details
See: [System Internals](../internals/system/)

## Contributing

**Found a gap in explanations?**

Good explanations should:
- Answer "why" and "how"
- Provide context and background
- Use analogies and examples
- Avoid step-by-step instructions (that's how-to)
- Avoid implementation details (that's internals)

---

**Remember**: Explanations help you understand. How-tos help you do.
