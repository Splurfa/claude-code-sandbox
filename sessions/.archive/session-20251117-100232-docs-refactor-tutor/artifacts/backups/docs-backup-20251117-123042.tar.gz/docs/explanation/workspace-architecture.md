# Workspace Architecture Explained

**Understanding the big picture of claude-flow+**

## What is Claude-Flow+?

This workspace is **claude-flow+ (custom extended version)**, NOT a stock claude-flow installation.

```
Stock Claude-Flow (98% of system)
        +
Custom Extensions (2% of system)
        =
Claude-Flow+ Workspace
```

**Key Point**: Built **ON TOP OF** stock claude-flow, not a fork or replacement.

## The 30-Second Version

**What you have**:
- Stock claude-flow coordination tools (98%)
- Custom session organization (1.5%)
- Optional learning pipeline (0.5%)

**What this means**:
- All standard claude-flow commands work
- Extra structure for organizing artifacts
- Optional advanced features (AgentDB, ReasoningBank)

**Stock-First Score: 98%** (higher than initial 82% claim)

## Architecture Layers

```
┌─────────────────────────────────────────────────────┐
│           User Chat Interface (Claude Code)         │
│                     100% Stock                      │
└────────────────────┬────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────┐
│         MCP Coordination Layer (claude-flow)        │
│   swarm_init, agent_spawn, task_orchestrate        │
│                     100% Stock                      │
└────────────────────┬────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────┐
│        Execution Layer (Claude Code Task Tool)      │
│   Parallel agent spawning, subprocess isolation     │
│                     100% Stock                      │
└────────────────────┬────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────┐
│              Agent Layer (54 agents)                │
│   researcher, coder, tester, architect, etc.        │
│              98% Stock, 2% Custom                   │
└────────────────────┬────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────┐
│           Persistence Layer (3 databases)           │
│   .swarm/memory.db (100% stock)                     │
│   sessions/ organization (custom)                   │
│   Captain's Log (95% stock hook + 5% script)        │
└─────────────────────────────────────────────────────┘
```

## Stock vs Custom: What's What?

### 100% Stock (Core System)

**Memory Database** (`.swarm/memory.db`)
- SQLite key-value store
- Stock schema, stock access methods
- Used by all agents for coordination
- **Usage**: `mcp__claude-flow__memory_usage` MCP tool

**MCP Tools**
- Swarm initialization
- Agent spawning
- Task orchestration
- Memory management
- **Access**: Via MCP protocol

**Hooks System**
- Pre-task, post-task, session-end
- Auto-fire on operations
- **Execution**: `npx claude-flow@alpha hooks <command>`

**Agent Framework**
- 54 specialized agent types
- Parallel execution via Task tool
- Shared memory coordination
- **Stock**: Agent framework itself

### Custom Extensions (2%)

**Session Organization** (`sessions/`)
- Directory structure: `sessions/$SESSION_ID/artifacts/`
- File routing by type (code, tests, docs, scripts, notes)
- **Why**: Stock doesn't prescribe artifact organization
- **Tools**: 100% stock (bash, mkdir, ls)

**Captain's Log** (`sessions/captains-log/`)
- Daily markdown journal
- Human-readable decision tracking
- **Stock**: Journal hook concept
- **Custom**: Bash implementation script (84 lines)

**Optional Learning** (Inactive by default)
- AgentDB vector search (0 episodes)
- ReasoningBank trajectory learning (0 trajectories)
- **Why**: Infrastructure exists, awaiting data
- **Stock**: Table schemas provided

## Design Philosophy

### Stock-First Principle

**Definition**: Use claude-flow built-in features first, only add custom wrappers when necessary.

**Application**:
```
Question: "Should we build X?"
    ↓
Check: Does stock claude-flow provide this?
    ↓
Yes: Use stock feature
No: Is it essential?
    ↓
Yes: Add thin wrapper using stock tools
No: Don't build it
```

**Examples**:
- ✅ Memory storage → Use stock `.swarm/memory.db`
- ✅ Agent coordination → Use stock MCP tools
- ✅ Hooks → Use stock hook system
- ⚠️ Session organization → Add thin wrapper (no stock equivalent)
- ❌ Custom framework → Don't build (stock is enough)

### Thin Wrapper Pattern

When custom code is needed, keep it minimal:

**File Routing** (0 custom framework)
- No new code, just CLAUDE.md instructions
- Uses stock mkdir, ls, cp
- AI follows routing rules

**Captain's Log** (84 lines bash)
- Thin script wrapping stock journal hook
- Uses stock cat, date, echo
- No custom database or storage

**Session Management** (150 lines bash)
- Auto-initialization script
- Uses stock mkdir, touch, cat
- No framework overhead

### Parallel-First Execution

Execute related operations simultaneously:

```javascript
// ✅ CORRECT: All agents in one message (10-20x faster)
Task("Research agent", "...", "researcher")
Task("Coder agent", "...", "coder")
Task("Tester agent", "...", "tester")
Task("Reviewer agent", "...", "reviewer")

// ❌ WRONG: Sequential spawning (slow)
Message 1: Task("Research agent")
Message 2: Task("Coder agent")
Message 3: Task("Tester agent")
Message 4: Task("Reviewer agent")
```

**Why**: Claude Code's Task tool supports parallel subprocess execution.

### Memory-First Coordination

Agents coordinate through shared memory, not direct messaging:

```javascript
// Agent A stores finding
mcp__claude-flow__memory_usage({
  action: "store",
  key: "auth/pattern",
  value: "JWT with refresh tokens",
  namespace: "swarm"
})

// Agent B retrieves finding
mcp__claude-flow__memory_usage({
  action: "retrieve",
  key: "auth/pattern",
  namespace: "swarm"
})
```

**Benefits**:
- No race conditions
- Scales to N agents
- Persistent across sessions
- Simple key-value model

## Directory Structure Explained

### Stock Directories

```
.swarm/                    # ✅ Stock claude-flow state
├── memory.db              # Key-value storage (SQLite)
└── backups/               # Session snapshots
```

### Custom Directories

```
sessions/                  # ⚠️ Custom artifact organization
├── captains-log/          # Daily journal logs
│   └── YYYY-MM-DD.md
└── session-YYYYMMDD-*/    # Session workspaces
    ├── metadata.json      # Session info
    ├── session-summary.md # Summary
    └── artifacts/         # Organized outputs
        ├── code/
        ├── tests/
        ├── docs/
        ├── scripts/
        └── notes/

.claude/                   # ⚠️ Custom infrastructure
├── agents/                # Agent patterns (hive-mind)
├── hooks/                 # Hook wrappers
├── session/               # Session management scripts
├── skills/                # 28 AI skills
└── settings.json          # Configuration
```

### Optional Directories

```
.agentdb/                  # Optional: Vector database
└── reasoningbank.db       # 0 episodes (inactive)

.hive-mind/                # Optional: Advanced coordination
└── hive.db                # If using hive-mind wizard
```

## Component Interactions

### Happy Path: Feature Development

```
1. User: "Build authentication system"
       ↓
2. MCP Tools: Define coordination strategy
   • swarm_init(topology: "mesh")
   • agent_spawn(type: "researcher")
   • agent_spawn(type: "coder")
   • agent_spawn(type: "tester")
       ↓
3. Claude Code Task Tool: Spawn agents in parallel
   • Task("Researcher", "Analyze auth patterns", "researcher")
   • Task("Coder", "Implement JWT auth", "coder")
   • Task("Tester", "Write auth tests", "tester")
       ↓
4. Agents execute simultaneously:
   • Researcher → Stores patterns in memory
   • Coder → Retrieves patterns, writes code
   • Tester → Retrieves code structure, writes tests
       ↓
5. Each agent:
   • Fires pre-task hook (track start)
   • Reads from .swarm/memory.db (past decisions)
   • Writes files to sessions/$SESSION_ID/artifacts/
   • Updates memory with findings
   • Fires post-task hook (track completion)
       ↓
6. Results aggregated and presented
       ↓
7. Session closeout:
   • Generate summary
   • User reviews (HITL)
   • Archive to .swarm/backups/
   • Extract decisions → Captain's Log
```

### Data Flow Example

```
┌─────────────────┐
│  Agent A        │
│  (Researcher)   │
└────────┬────────┘
         │ Stores: "auth pattern = JWT"
         ↓
┌─────────────────────────────────┐
│  .swarm/memory.db               │
│  Key: auth/pattern              │
│  Value: "JWT with refresh"      │
└────────┬────────────────────────┘
         │ Retrieves: auth/pattern
         ↓
┌─────────────────┐
│  Agent B        │
│  (Coder)        │
└────────┬────────┘
         │ Stores: "implementation = complete"
         ↓
┌─────────────────────────────────┐
│  .swarm/memory.db               │
│  Key: auth/status               │
│  Value: "complete"              │
└────────┬────────────────────────┘
         │ Retrieves: auth/status
         ↓
┌─────────────────┐
│  Agent C        │
│  (Tester)       │
└─────────────────┘
```

## Why This Architecture?

### Benefits of Stock-First

1. **Compatibility** - Works with official claude-flow updates
2. **Simplicity** - No custom framework to maintain
3. **Performance** - Uses optimized stock tools
4. **Community** - Standard patterns others understand
5. **Updates** - Auto-updates from `npx claude-flow@alpha`

### Benefits of Custom Extensions

1. **Organization** - Session artifacts stay structured
2. **Traceability** - Know what came from which chat
3. **Journaling** - Human-readable decision log
4. **Learning** (optional) - Pattern extraction for future use

### Trade-offs

**Stock-only approach**:
- ✅ Minimal setup
- ✅ Official support
- ❌ Less structured artifacts
- ❌ No session organization

**Claude-flow+ approach**:
- ✅ Organized artifacts
- ✅ Session traceability
- ✅ Compatible with stock
- ⚠️ Extra scripts to maintain (minimal)

## Migration Scenarios

### To Pure Stock

If you want 100% stock claude-flow:

```bash
# 1. Backup current setup
tar -czf claude-flow-plus-backup.tar.gz .

# 2. Run stock initialization
npx claude-flow@alpha hive init --topology mesh

# 3. Migrate memory database (compatible)
cp .swarm/memory.db .swarm/memory.db.backup

# What you lose:
# - Session organization
# - File routing
# - Captain's Log
# - ReasoningBank (inactive anyway)
```

### From Stock to Claude-Flow+

If others want this setup:

```bash
# 1. Copy infrastructure
cp -r /path/to/claude-flow-plus/.claude .
cp -r /path/to/claude-flow-plus/.claude/session .

# 2. Update CLAUDE.md
# Add session management protocol

# 3. Initialize session structure
bash .claude/session/auto-init.sh "first-session"

# 4. (Optional) Set up learning
npx agentdb@latest init .agentdb/reasoningbank.db
```

## When to Choose What

### Choose Pure Stock If...

- ✅ You're new to claude-flow
- ✅ You don't need artifact organization
- ✅ You want official documentation only
- ✅ You're collaborating with stock users
- ✅ You prefer minimal configuration

### Choose Claude-Flow+ If...

- ✅ You need structured session organization
- ✅ You want traceability across chats
- ✅ You value decision journaling
- ✅ You're okay with 2% custom scripts
- ✅ You want file routing automation

### Hybrid Approach (Recommended)

- ✅ Run `npx claude-flow@alpha hive init` for stock foundation
- ✅ Add `.claude/` extensions for session organization
- ✅ Use stock MCP tools for all coordination
- ✅ Use custom scripts only for artifacts/journaling
- ✅ Document clearly what's stock vs custom

## Scalability

### Vertical (Single Session)

- **Max Agents**: 100 (configurable)
- **Typical Usage**: 3-8 agents per task
- **Performance**: 10-20x speedup with parallel spawning
- **Memory**: SQLite handles 36K+ entries

### Horizontal (Multiple Sessions)

- **Concurrent Sessions**: Unlimited (one per chat thread)
- **Session Isolation**: Separate artifact directories
- **Memory Namespacing**: Prevents conflicts
- **Backup Storage**: Linear growth in `.swarm/backups/`

## Performance Characteristics

| Metric | Stock claude-flow | Claude-flow+ | Impact |
|--------|-------------------|--------------|--------|
| Agent Spawning | 10-20x parallel | Same | No change |
| Memory Access | SQLite (fast) | Same | No change |
| File I/O | Native | Session routing | +1 mkdir |
| Hook Execution | Native | Same | No change |
| Session Closeout | N/A | +2 seconds | Minimal |

**Conclusion**: Custom extensions add negligible overhead (<1%).

## Summary

**Claude-Flow+ is stock claude-flow with organized artifacts.**

**What's stock (98%)**:
- Memory database
- MCP coordination
- Agent framework
- Hooks system
- Parallel execution

**What's custom (2%)**:
- Session directory structure
- File routing instructions
- Captain's Log script
- Optional learning pipeline (inactive)

**Philosophy**: Use stock, organize artifacts, journal decisions, stay compatible.

## Related Documentation

- **Deep Dive**: [Architecture Overview (Internals)](../internals/system/architecture-overview.md)
- **Session Details**: [Session Management Explained](session-management.md)
- **File Organization**: [File Routing Explained](file-routing.md)
- **Stock Comparison**: [Stock vs Custom (Internals)](../internals/system/stock-vs-custom.md)

---

**Remember**: 98% stock tools, 2% organized structure. Best of both worlds.
