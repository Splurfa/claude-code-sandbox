# Session Management Explained

**Understanding how sessions organize your work**

## What is a Session?

A **session** is a complete chat conversation with all its artifacts organized in one place. Think of it as a project workspace that captures everything from a single chat thread.

**Core Principle**: ONE SESSION = ONE CHAT THREAD

- Not per task
- Not per agent
- One chat conversation = One session directory

## Why Sessions Matter

Without sessions, your artifacts would be scattered:
- Code files mixed with old experiments
- Tests from different features combined
- Documentation from multiple projects tangled together

Sessions solve this by creating a **structured workspace** for each chat conversation.

## The Session Lifecycle

```
New Chat Thread
    ↓
Session Created Automatically
    ↓
All Work Goes to: sessions/$SESSION_ID/artifacts/
    ↓
Chat Ends → Session Closeout
    ↓
Archived to: .swarm/backups/
```

### 1. Session Creation

When you start a new chat, a session directory is automatically created:

```
sessions/session-20251113-150000-api-development/
├── metadata.json                   # Session metadata
├── session-summary.md              # Narrative summary
└── artifacts/                      # All session outputs
    ├── code/                       # Source code files
    ├── tests/                      # Test files
    ├── docs/                       # Documentation
    ├── scripts/                    # Utility scripts
    └── notes/                      # Working notes
```

**Session ID Format**: `session-YYYYMMDD-HHMMSS-<topic>`
- Date and time for uniqueness
- Topic inferred from first message
- Example: `session-20251113-150000-api-development`

### 2. Active Work Phase

During the session, **all artifacts go to the session directory**:

```bash
# Code files
sessions/$SESSION_ID/artifacts/code/server.js
sessions/$SESSION_ID/artifacts/code/App.jsx

# Tests
sessions/$SESSION_ID/artifacts/tests/server.test.js
sessions/$SESSION_ID/artifacts/tests/integration.test.js

# Documentation
sessions/$SESSION_ID/artifacts/docs/API.md
sessions/$SESSION_ID/artifacts/docs/architecture.md

# Scripts
sessions/$SESSION_ID/artifacts/scripts/deploy.sh
sessions/$SESSION_ID/artifacts/scripts/setup.sh

# Notes
sessions/$SESSION_ID/artifacts/notes/decisions.md
sessions/$SESSION_ID/artifacts/notes/blockers.md
```

**Key Point**: Never write to root `tests/`, `docs/`, or `scripts/` directories. Always use session artifacts.

### 3. Session Closeout

When you're done with a chat session:

1. **Collect** - Generate summary of all work
2. **Review** - You review and approve (HITL - Human in the Loop)
3. **Archive** - System backs up session state
4. **Promote** (Optional) - Move artifacts to permanent project docs

**What gets created**:
- `.swarm/backups/session-YYYYMMDD-HHMMSS-topic.json` - Session snapshot
- Captain's Log entry (if approved)
- Memory storage of key decisions
- Frozen session directory

## Sub-Tasks Within Sessions

**Important**: Don't create new sessions for sub-tasks!

Instead, organize sub-tasks within the session:

```
sessions/session-20251113-150000-fullstack-app/
└── artifacts/
    ├── code/
    │   ├── backend/           # Backend sub-task
    │   ├── frontend/          # Frontend sub-task
    │   └── database/          # Database sub-task
    ├── tests/
    │   ├── backend.test.js
    │   ├── frontend.test.js
    │   └── integration.test.js
    └── notes/
        ├── backend-decisions.md
        ├── frontend-design.md
        └── database-schema.md
```

This keeps related work together while maintaining organization.

## Agent Integration

When spawning agents, include the session path:

```javascript
Task("Backend Developer",
     "Build REST API. Save to sessions/$SESSION_ID/artifacts/code/backend/",
     "backend-dev")

Task("Frontend Developer",
     "Create React UI. Save to sessions/$SESSION_ID/artifacts/code/frontend/",
     "coder")

Task("Test Engineer",
     "Write tests. Save to sessions/$SESSION_ID/artifacts/tests/",
     "tester")
```

Agents automatically coordinate through:
- Shared memory (`.swarm/memory.db`)
- Session artifacts (file output)
- Hooks (pre-task, post-task)

## File Routing Rules

| File Type | Destination | Example |
|-----------|-------------|---------|
| Source code | `sessions/$SESSION_ID/artifacts/code/` | `server.js`, `App.jsx` |
| Tests | `sessions/$SESSION_ID/artifacts/tests/` | `server.test.js` |
| Documentation | `sessions/$SESSION_ID/artifacts/docs/` | `API.md`, `README.md` |
| Scripts | `sessions/$SESSION_ID/artifacts/scripts/` | `deploy.sh`, `build.sh` |
| Notes | `sessions/$SESSION_ID/artifacts/notes/` | `ideas.md`, `decisions.md` |

**Exceptions** - Only edit existing project files in their original locations:
- `package.json`
- `CLAUDE.md`
- `tsconfig.json`
- Root configuration files

## Manual Session Management

### Creating a Session Manually

```bash
# Using auto-init script
bash .claude/session/auto-init.sh "my-project-topic"

# Or with detection script
bash .claude/session/detect-and-init.sh
```

### Checking Current Session

```bash
# Show session ID
echo $SESSION_ID

# Verify session exists
ls -la "sessions/$SESSION_ID/artifacts/"

# View session metadata
cat "sessions/$SESSION_ID/metadata.json"
```

### Closing a Session Manually

```bash
# Run closeout hook
npx claude-flow@alpha hooks session-end --generate-summary true

# Or use session closeout skill
# See: .claude/skills/session-closeout/
```

## Why This Architecture?

**Benefits**:
1. **Traceability** - Know exactly what came from which chat
2. **Organization** - All related artifacts in one place
3. **Reproducibility** - Session can be reopened and continued
4. **Archival** - Easy to backup or share complete work
5. **Collaboration** - Clear structure for team handoffs

**Compared to alternatives**:
- **No structure**: Files scattered everywhere
- **Per-task sessions**: Too many directories, hard to navigate
- **Monolithic workspace**: Everything mixed, hard to find anything

## Common Patterns

### Pattern 1: Feature Development

```
Session: session-20251113-150000-user-authentication
Artifacts:
  code/auth/           # Auth module
  tests/auth/          # Auth tests
  docs/auth-flow.md    # How it works
  notes/decisions.md   # Why we chose JWT
```

### Pattern 2: Bug Investigation

```
Session: session-20251113-160000-memory-leak-fix
Artifacts:
  code/fixes/          # Patched files
  tests/regression/    # Prevent recurrence
  docs/analysis.md     # Root cause analysis
  notes/timeline.md    # Investigation notes
```

### Pattern 3: Research & Prototyping

```
Session: session-20251113-170000-ai-integration-research
Artifacts:
  code/prototypes/     # Quick experiments
  docs/comparison.md   # Technology comparison
  notes/findings.md    # Research insights
```

## Integration with Other Systems

### Captain's Log

At session closeout, approved summaries are copied to:
```
sessions/captains-log/YYYY-MM-DD.md
```

This creates a **permanent narrative record** of decisions.

### Memory Database

Key decisions and patterns stored in:
```
.swarm/memory.db
```

Available to future sessions via:
```javascript
mcp__claude-flow__memory_usage({
  action: "retrieve",
  key: "decision/authentication-strategy",
  namespace: "default"
})
```

### Session Backups

Complete session state archived to:
```
.swarm/backups/session-YYYYMMDD-HHMMSS-topic.json
```

Includes:
- All file paths
- Metadata
- Summary
- Metrics

## Best Practices

### DO ✅

- Create one session per chat thread
- Keep all artifacts in session directory
- Use subdirectories for sub-tasks
- Write descriptive session topics
- Review and approve closeouts
- Archive completed sessions

### DON'T ❌

- Create new sessions for sub-tasks
- Write to root `tests/`, `docs/`, `scripts/`
- Skip session closeout
- Delete session directories manually
- Mix artifacts from multiple sessions
- Forget to set `$SESSION_ID` variable

## Troubleshooting

**Problem**: No session directory exists

**Solution**:
```bash
bash .claude/session/auto-init.sh "topic-name"
```

**Problem**: Unsure which session is active

**Solution**:
```bash
echo $SESSION_ID
ls -la sessions/
```

**Problem**: Session not closing properly

**Solution**:
```bash
npx claude-flow@alpha hooks session-end --export-metrics true
```

## Related Documentation

- **Implementation Details**: [Session Lifecycle (Internals)](../internals/system/session-lifecycle.md)
- **File Routing**: [File Routing Explained](file-routing.md)
- **Closeout Process**: [Session Closeout How-To](../guides/how-to/session-closeout.md) *(future)*

---

**Remember**: One chat = One session. Keep it simple, keep it organized.
