# Tutorials

**Learn by doing** with step-by-step guided lessons.

## What Are Tutorials?

Tutorials are **learning-oriented** documents that teach you skills through practice. They're like a cooking class - you follow along and build something real.

**Goals**:
- Build confidence through successful completion
- Learn fundamental skills
- Get familiar with common patterns
- Create working examples

**Not Goals**:
- Comprehensive coverage (that's reference)
- Problem-solving (that's how-to)
- Theory and concepts (that's explanation)

## Diátaxis Framework

```
Tutorials ← You are here
    ↓
Learning-oriented
    ↓
Step-by-step lessons
    ↓
Practical education
```

**Different from**:
- **How-to Guides** - Assumes you know basics, solves specific problems
- **Explanations** - Theoretical understanding, no hands-on
- **Reference** - Quick lookups, no learning path

## Available Tutorials

### Getting Started

**Status**: No tutorials created yet

**Planned**:
- Your First Session - Create and organize a simple project
- Multi-Agent Coordination - Build a feature with multiple agents
- Using Memory - Store and retrieve decisions across sessions
- Session Closeout - Complete and archive your work

## Using Existing Learning Materials

While formal tutorials are being developed, you can learn through:

### 1. Quick Start (CLAUDE.md)
Location: `CLAUDE.md` (project root)
- Basic commands
- Session management quick reference
- File routing rules
- Agent spawning examples

### 2. Integration Testing Guide
Location: `docs/guides/how-to/integration-testing-guide.md`
- Hands-on testing procedures
- Verification steps
- Common workflows

### 3. System Internals
Location: `docs/internals/system/`
- Architecture overview
- Component interactions
- Data flow diagrams

## Creating Your Own Learning Path

### For Complete Beginners

1. Read: [Workspace Architecture (Explanation)](../explanation/workspace-architecture.md)
2. Practice: Run `npx claude-flow@alpha --help`
3. Experiment: Create your first session
4. Build: Use the integration testing guide

### For Experienced Users

1. Read: [Session Management (Explanation)](../explanation/session-management.md)
2. Practice: Multi-agent coordination
3. Build: Complex workflows with memory
4. Master: Advanced patterns and optimization

## Tutorial Guidelines

**When tutorials are created, they should**:
- Start with a clear goal ("You will build...")
- List prerequisites upfront
- Provide all necessary code/commands
- Explain each step briefly
- Include checkpoints for verification
- End with a working example
- Suggest next steps

**Good tutorial topics**:
- First session workflow
- Building a REST API with agents
- Testing and quality verification
- Advanced coordination patterns
- Learning from past sessions

## Related Documentation

### After Completing Tutorials

**Next steps**:
- **How-to Guides** - Solve specific problems
- **Explanations** - Deepen understanding
- **Reference** - Quick lookups during work
- **Internals** - System architecture details

### Complementary Material

- [How-to Guides](../guides/how-to/) - Task-oriented recipes
- [Explanations](../explanation/) - Conceptual understanding
- [Reference](../guides/reference/) - Quick facts
- [Internals](../internals/system/) - System mechanics

## Contributing Tutorials

**Want to create a tutorial?**

Good structure:
1. **Introduction** - What you'll build, why it matters
2. **Prerequisites** - What you need to know/have
3. **Step 1-N** - Incremental building blocks
4. **Verification** - Check it works
5. **Summary** - What you learned
6. **Next Steps** - Where to go from here

Save to: `docs/tutorials/your-tutorial-name.md`

## Temporary Alternative

**Until tutorials exist**, use this learning path:

```bash
# 1. Understand the system
Read: docs/explanation/workspace-architecture.md

# 2. Learn session basics
Read: docs/explanation/session-management.md

# 3. Try basic commands
npx claude-flow@alpha --version
npx claude-flow@alpha hooks memory --action list

# 4. Create a test session
bash .claude/session/auto-init.sh "learning-session"

# 5. Spawn an agent
# Use Claude Code's Task tool in a chat

# 6. Review integration guide
Read: docs/guides/how-to/integration-testing-guide.md

# 7. Run feature checks
Read: docs/guides/reference/feature-verification-checklist.md
```

---

**Remember**: Tutorials teach skills. How-tos solve problems. Choose based on your goal.
