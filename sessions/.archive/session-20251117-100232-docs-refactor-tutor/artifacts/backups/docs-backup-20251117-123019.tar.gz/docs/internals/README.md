# System Internals

**Deep technical documentation** for understanding how the system works under the hood.

## What Are Internals?

Internals documentation explains the **technical mechanics** of the system. This is for when you need to:
- Understand implementation details
- Debug complex issues
- Extend or integrate with the system
- Contribute to development

**Goals**:
- Accurate technical specifications
- Component interaction details
- Data flow and state management
- Integration points and APIs

**Not Goals**:
- Step-by-step tutorials (that's tutorials)
- Task recipes (that's how-to)
- High-level concepts (that's explanation)

## Diátaxis Framework

```
Internals ← You are here
    ↓
Technical reference
    ↓
System mechanics
    ↓
Implementation details
```

**Different from**:
- **Explanations** - High-level concepts without deep technical details
- **How-to** - Practical tasks without implementation mechanics
- **Reference** - Quick lookups without system context

## Available Internals Documentation

### System Architecture

**[Architecture Overview](system/architecture-overview.md)**
- 30,000-foot view of the system
- Component layers and interactions
- Technology stack
- Performance characteristics

**[Stock vs Custom](system/stock-vs-custom.md)**
- What's from stock claude-flow
- What's custom extension
- Compliance matrix
- Migration scenarios

### Component Details

**[Memory Architecture](system/memory-architecture.md)**
- `.swarm/memory.db` internals
- Schema and table structures
- Access patterns
- Performance considerations

**[Coordination Mechanics](system/coordination-mechanics.md)**
- How agents work together
- Memory-first coordination pattern
- MCP tool integration
- Parallel execution model

**[Session Lifecycle](system/session-lifecycle.md)**
- Session state machine
- Creation, active, closeout phases
- Backup and archival process
- Hook integration points

### Integration and Data Flow

**[Data Flow](system/data-flow.md)**
- Information movement through system
- Agent-to-agent communication
- Memory read/write patterns
- File system interactions

**[Integration Points](system/integration-points.md)**
- MCP tool interfaces
- Hook system APIs
- Memory database access
- Extension mechanisms

**[Hooks and Automation](system/hooks-and-automation.md)**
- Hook execution flow
- Auto-fire mechanisms
- Claude Code integration
- Custom hook development

## Who Should Read This

### You Should Read Internals If...

- ✅ You're debugging a complex issue
- ✅ You're extending the system
- ✅ You need to understand component interactions
- ✅ You're contributing to development
- ✅ You're optimizing performance

### You Probably Want Explanations If...

- ❌ You just want to understand concepts
- ❌ You don't need implementation details
- ❌ You're looking for "why" not "how exactly"

### You Probably Want How-To If...

- ❌ You have a specific task to complete
- ❌ You want step-by-step instructions
- ❌ You don't care about internals

## Navigation

### By System Component

| Component | Internals | Explanation | How-To |
|-----------|-----------|-------------|---------|
| **Architecture** | [Overview](system/architecture-overview.md) | [Workspace Architecture](../explanation/workspace-architecture.md) | *(future)* |
| **Memory** | [Memory Architecture](system/memory-architecture.md) | *(future)* | *(future)* |
| **Sessions** | [Session Lifecycle](system/session-lifecycle.md) | [Session Management](../explanation/session-management.md) | *(future)* |
| **Coordination** | [Coordination Mechanics](system/coordination-mechanics.md) | *(future)* | [Integration Testing](../guides/how-to/integration-testing-guide.md) |
| **Hooks** | [Hooks & Automation](system/hooks-and-automation.md) | *(future)* | *(future)* |

### By Learning Goal

**I need to understand...**
- How components connect → [Architecture Overview](system/architecture-overview.md)
- What's stock vs custom → [Stock vs Custom](system/stock-vs-custom.md)
- How data moves → [Data Flow](system/data-flow.md)
- How agents coordinate → [Coordination Mechanics](system/coordination-mechanics.md)
- How sessions work → [Session Lifecycle](system/session-lifecycle.md)
- How memory works → [Memory Architecture](system/memory-architecture.md)
- How to extend the system → [Integration Points](system/integration-points.md)

### Quick Start

**New to the internals?** Start here:

1. [Architecture Overview](system/architecture-overview.md) - Get the big picture
2. [Stock vs Custom](system/stock-vs-custom.md) - Understand what's what
3. Topic-specific docs based on your needs

## Technical Specifications

### System Requirements

- **Node.js**: 18+ (for claude-flow)
- **SQLite**: 3.x (bundled)
- **Bash**: 4.x+ (for scripts)
- **Git**: 2.x+ (for checkpoints)

### Performance Metrics

From `docs/internals/system/README.md`:
- **84.8% SWE-Bench solve rate**
- **32.3% token reduction**
- **2.8-4.4x speed improvement**
- **10-20x parallel agent spawning speedup**

### Stock Compliance

- **Overall**: 98% stock-first
- **Memory**: 100% stock
- **MCP Tools**: 100% stock
- **Hooks**: 100% stock
- **Session Organization**: Custom (2%)

## Related Documentation

### For Conceptual Understanding
See: [Explanations](../explanation/)

### For Practical Tasks
See: [How-to Guides](../guides/how-to/)

### For Quick Reference
See: [Reference Guides](../guides/reference/)

### For Learning
See: [Tutorials](../tutorials/) (when available)

## Contributing to Internals

**Adding internals documentation?**

Good internals docs should:
- Be technically accurate and detailed
- Include diagrams where helpful
- Document actual behavior, not idealized
- Cover edge cases and failure modes
- Reference source code locations
- Explain implementation choices

**Save to**: `docs/internals/system/your-topic.md`

**Update**: This README with navigation links

## Debugging Resources

### Common Debugging Paths

**Memory issues** →
1. [Memory Architecture](system/memory-architecture.md)
2. [Data Flow](system/data-flow.md)
3. Check `.swarm/memory.db` directly

**Coordination problems** →
1. [Coordination Mechanics](system/coordination-mechanics.md)
2. [Hooks & Automation](system/hooks-and-automation.md)
3. Check agent spawning patterns

**Session errors** →
1. [Session Lifecycle](system/session-lifecycle.md)
2. [Integration Points](system/integration-points.md)
3. Check `sessions/$SESSION_ID/`

**Integration failures** →
1. [Integration Points](system/integration-points.md)
2. [Stock vs Custom](system/stock-vs-custom.md)
3. Verify MCP tool availability

## Summary

**Internals documentation explains the technical implementation.**

**Key principles**:
- 98% stock claude-flow foundation
- 2% custom organization layer
- Memory-first coordination
- Parallel-first execution
- Stock-first implementation

**Use internals when**:
- You need implementation details
- You're extending the system
- You're debugging complex issues
- You need precise technical specs

---

**Remember**: Internals for mechanics, explanations for concepts, how-tos for tasks.
