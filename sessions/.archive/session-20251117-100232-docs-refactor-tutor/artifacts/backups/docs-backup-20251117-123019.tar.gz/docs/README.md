# Documentation

**Organized using the Diátaxis framework** for clear, purpose-driven documentation.

## Documentation Structure

This documentation is organized by **what you're trying to achieve**, not by topic. Each type serves a different purpose:

```
┌─────────────────────────────────────────────────┐
│                   Diátaxis                      │
│                                                 │
│   LEARNING          │        WORKING            │
│                     │                           │
│   Tutorials    ←────┼────→   How-to Guides      │
│   (lessons)         │        (recipes)          │
│                     │                           │
│ ─────────────────── │ ───────────────────────── │
│                     │                           │
│   Explanation  ←────┼────→   Reference          │
│   (understanding)   │        (lookups)          │
│                     │                           │
│  THEORETICAL        │        PRACTICAL          │
└─────────────────────────────────────────────────┘
```

### The Four Types

| Type | Purpose | You Want To... |
|------|---------|----------------|
| **[Tutorials](tutorials/)** | Learn by doing | Build skills through practice |
| **[How-to](guides/how-to/)** | Solve problems | Complete a specific task |
| **[Explanation](explanation/)** | Understand concepts | Know why/how it works |
| **[Reference](guides/reference/)** | Look up facts | Find quick information |

**Plus**: [Internals](internals/) - Deep technical mechanics (for developers/debuggers)

## Quick Navigation

### 🎓 I'm New Here

**Start with**:
1. [Workspace Architecture Explained](explanation/workspace-architecture.md) - What is this?
2. [Session Management Explained](explanation/session-management.md) - How work is organized
3. [File Routing Explained](explanation/file-routing.md) - Where files go

**Then**:
- [Tutorials](tutorials/) - Build your first project (coming soon)
- [How-to: Integration Testing](guides/how-to/integration-testing-guide.md) - Verify everything works

### 🔧 I Have a Specific Task

**Go to**: [How-to Guides](guides/how-to/)

Common tasks:
- [Integration Testing](guides/how-to/integration-testing-guide.md) - Test the system
- [Choose Coordination Approach](guides/how-to/choose-coordination-approach.md) - Pick right pattern
- [Zero-Risk Execution](guides/how-to/zero-risk-execution-pattern.md) - Safe workflows

### 🧠 I Want to Understand

**Go to**: [Explanations](explanation/)

Core concepts:
- [Session Management](explanation/session-management.md) - How sessions organize work
- [File Routing](explanation/file-routing.md) - Automatic file organization
- [Workspace Architecture](explanation/workspace-architecture.md) - Stock vs custom breakdown

### 📖 I Need Quick Facts

**Go to**: [Reference](guides/reference/)

Quick lookups:
- [Feature Verification Checklist](guides/reference/feature-verification-checklist.md)
- [File Routing Changes](guides/reference/file-routing-changes.md)
- [Skill.md Changes](guides/reference/skill-md-changes.md)

### 🔍 I'm Debugging/Extending

**Go to**: [System Internals](internals/system/)

Technical details:
- [Architecture Overview](internals/system/architecture-overview.md) - System design
- [Coordination Mechanics](internals/system/coordination-mechanics.md) - Agent interaction
- [Memory Architecture](internals/system/memory-architecture.md) - Database internals
- [Session Lifecycle](internals/system/session-lifecycle.md) - Session state machine
- [Stock vs Custom](internals/system/stock-vs-custom.md) - What's what

## Role-Based Entry Points

### For New Users

```
1. Read: Workspace Architecture (explanation)
2. Try: First session workflow (tutorial - coming soon)
3. Practice: Integration testing (how-to)
4. Reference: Feature checklist (reference)
```

### For Developers

```
1. Read: Architecture Overview (internals)
2. Understand: Coordination Mechanics (internals)
3. Extend: Integration Points (internals)
4. Debug: Troubleshooting Guide (how-to)
```

### For Power Users

```
1. Master: Advanced Patterns (guides/advanced)
2. Optimize: Performance tuning (internals)
3. Customize: Extension development (internals)
```

## What's Where

### Main Categories

#### [📚 Tutorials](tutorials/)
- **Purpose**: Learn by building
- **Format**: Step-by-step lessons
- **Status**: Coming soon
- **Current**: Use integration testing guide as hands-on practice

#### [🔧 How-to Guides](guides/how-to/)
- **Purpose**: Solve specific problems
- **Format**: Task-oriented recipes
- **Available**: 3 guides
  - Integration testing
  - Coordination approach selection
  - Zero-risk execution pattern

#### [💡 Explanations](explanation/)
- **Purpose**: Understand concepts
- **Format**: Theory and context
- **Available**: 3 core explanations
  - Session management
  - File routing
  - Workspace architecture

#### [📖 Reference](guides/reference/)
- **Purpose**: Quick lookups
- **Format**: Facts and checklists
- **Available**: 3 references
  - Feature verification checklist
  - File routing changes
  - Skill.md changes

#### [⚙️ Internals](internals/system/)
- **Purpose**: Technical deep-dives
- **Format**: Implementation details
- **Available**: 9 technical docs
  - Architecture overview
  - Coordination mechanics
  - Memory architecture
  - Session lifecycle
  - Data flow
  - Integration points
  - Hooks and automation
  - Stock vs custom analysis

### Advanced Topics

#### [🚀 Advanced Guides](guides/advanced/)
- **Adaptive Pivot Protocol** - Dynamic workflow adjustment
- More advanced patterns coming soon

#### [🛠️ Troubleshooting](guides/troubleshooting/)
- **Troubleshooting Guide** - Common issues and solutions

## Documentation Philosophy

### Diátaxis Principles

Each documentation type has a **single, clear purpose**:

**Tutorials** = Learning
- "By the end of this, you will have built..."
- Step-by-step, safe environment
- Teaches skills, not just facts

**How-to** = Problem Solving
- "To accomplish X, do Y"
- Task-focused, assumes basics
- Practical recipes

**Explanation** = Understanding
- "Here's why it works this way..."
- Conceptual, theoretical
- Background and context

**Reference** = Information
- "The setting is...", "The command does..."
- Fact-based, accurate
- Quick lookups

### Why This Structure?

**Traditional approach** (by topic):
```
Sessions/
  - What is a session? (explanation)
  - How to create a session (how-to)
  - Session tutorial (tutorial)
  - Session API (reference)
```
❌ Hard to find what you need when you need it

**Diátaxis approach** (by purpose):
```
explanation/session-management.md  ← "I want to understand"
how-to/create-session.md          ← "I need to do this"
tutorials/first-session.md        ← "I want to learn"
reference/session-api.md          ← "I need to look this up"
```
✅ Find exactly what you need based on your goal

## Content Guidelines

### For Contributors

When adding documentation, ask:
- **What is the user trying to achieve?**
- **Learning** → Tutorial
- **Doing** → How-to
- **Understanding** → Explanation
- **Looking up** → Reference
- **Debugging/extending** → Internals

**Don't mix purposes!**
- ❌ Tutorial with long explanations → Boring
- ❌ How-to with teaching → Confusing
- ❌ Explanation with steps → Unclear
- ❌ Reference with theory → Frustrating

### Documentation Checklist

**Before publishing**:
- [ ] Purpose is clear (tutorial/how-to/explanation/reference/internals)
- [ ] Title matches purpose ("Explained", "How to", etc.)
- [ ] Content stays focused on one purpose
- [ ] Links to related docs in other categories
- [ ] Saved to correct directory
- [ ] Navigation updated (this README + category README)

## Finding What You Need

### By Goal

| I Want To... | Go To |
|--------------|-------|
| Learn from scratch | [Tutorials](tutorials/) |
| Complete a task | [How-to Guides](guides/how-to/) |
| Understand concepts | [Explanations](explanation/) |
| Look up a fact | [Reference](guides/reference/) |
| Debug/extend | [Internals](internals/) |

### By Topic

| Topic | Explanation | How-To | Reference | Internals |
|-------|-------------|--------|-----------|-----------|
| **Sessions** | [Session Mgmt](explanation/session-management.md) | *(future)* | *(future)* | [Lifecycle](internals/system/session-lifecycle.md) |
| **Files** | [File Routing](explanation/file-routing.md) | *(future)* | [Routing Changes](guides/reference/file-routing-changes.md) | [Data Flow](internals/system/data-flow.md) |
| **Architecture** | [Workspace Arch](explanation/workspace-architecture.md) | *(future)* | *(future)* | [Overview](internals/system/architecture-overview.md) |
| **Coordination** | *(future)* | [Choose Approach](guides/how-to/choose-coordination-approach.md) | *(future)* | [Mechanics](internals/system/coordination-mechanics.md) |
| **Testing** | *(future)* | [Integration Test](guides/how-to/integration-testing-guide.md) | [Feature Checklist](guides/reference/feature-verification-checklist.md) | *(future)* |

## What's Missing?

### Coming Soon

**Tutorials**:
- Your First Session
- Multi-Agent Coordination
- Using Memory Effectively
- Advanced Workflows

**How-to Guides**:
- Session Closeout Process
- Manual Session Management
- Memory Operations
- Custom Agent Creation

**Explanations**:
- Coordination Patterns
- Memory Management
- Hook System

**Reference**:
- MCP Tools Quick Reference
- Agent Types Catalog
- Memory Schema
- Hooks API

## Getting Help

### Step-by-Step

1. **Identify your goal**:
   - Learning? → Tutorials
   - Task? → How-to
   - Understanding? → Explanations
   - Looking up? → Reference
   - Debugging? → Internals

2. **Check category README**:
   - Each category has navigation
   - Find the specific doc you need

3. **Read the doc**:
   - Focused on single purpose
   - Links to related docs

4. **Still stuck?**:
   - Check troubleshooting guide
   - Review internals for deep dive
   - Consult CLAUDE.md for workspace config

## Related Resources

### In This Repository

- **[CLAUDE.md](../CLAUDE.md)** - Workspace configuration and quick reference
- **[.claude/skills/](../.claude/skills/)** - 28 AI skills for various tasks
- **[.claude/commands/](../.claude/commands/)** - Command documentation

### External

- **Stock Claude-Flow**: https://github.com/ruvnet/claude-flow
- **Claude Code**: Official Anthropic documentation
- **MCP Protocol**: Model Context Protocol specification

## Summary

**This documentation is organized by purpose, not topic.**

**Find what you need**:
- 🎓 Learn → [Tutorials](tutorials/)
- 🔧 Do → [How-to](guides/how-to/)
- 💡 Understand → [Explanations](explanation/)
- 📖 Look up → [Reference](guides/reference/)
- ⚙️ Debug → [Internals](internals/)

**Start here**:
- New user → [Workspace Architecture Explained](explanation/workspace-architecture.md)
- Specific task → [How-to Guides](guides/how-to/)
- Deep dive → [System Internals](internals/)

---

**Remember**: Match your goal to the documentation type. Don't waste time in the wrong category.
