# File Routing Explained

**Understanding where files go and why**

## What is File Routing?

File routing is the system that **automatically determines where to save files** based on their type and purpose. It ensures artifacts stay organized within session directories.

**Goal**: No more scattered files. Everything in its proper place.

## The Core Principle

```
Type-Based Organization
    ↓
Automatic Routing
    ↓
Session Artifacts
```

Instead of manually deciding "where should this go?", the system routes files automatically based on:
- File type (code, test, doc, script, note)
- Active session ID
- Purpose and context

## Routing Rules

### Standard Routes

| File Type | Auto-Routes To | Examples |
|-----------|----------------|----------|
| **Source Code** | `sessions/$SESSION_ID/artifacts/code/` | `.js`, `.jsx`, `.ts`, `.tsx`, `.py`, `.go` |
| **Tests** | `sessions/$SESSION_ID/artifacts/tests/` | `.test.js`, `.spec.ts`, `test_*.py` |
| **Documentation** | `sessions/$SESSION_ID/artifacts/docs/` | `.md`, `.txt`, API docs |
| **Scripts** | `sessions/$SESSION_ID/artifacts/scripts/` | `.sh`, `.bash`, build scripts |
| **Notes** | `sessions/$SESSION_ID/artifacts/notes/` | Working notes, decisions, ideas |

### Examples in Practice

```bash
# Writing a React component
Write "sessions/$SESSION_ID/artifacts/code/UserProfile.jsx"
# ✅ Routed to: code/ (source code)

# Writing a test
Write "sessions/$SESSION_ID/artifacts/tests/UserProfile.test.jsx"
# ✅ Routed to: tests/ (test file)

# Writing API documentation
Write "sessions/$SESSION_ID/artifacts/docs/API-Reference.md"
# ✅ Routed to: docs/ (documentation)

# Writing deployment script
Write "sessions/$SESSION_ID/artifacts/scripts/deploy.sh"
# ✅ Routed to: scripts/ (utility script)

# Writing design decisions
Write "sessions/$SESSION_ID/artifacts/notes/auth-strategy.md"
# ✅ Routed to: notes/ (working notes)
```

## Why File Routing Exists

### Problem Without Routing

```
project/
├── server.js                  # Which feature is this?
├── test.js                    # What does it test?
├── old-server.js              # Still needed?
├── API.md                     # Current or outdated?
├── deploy.sh                  # Works with what?
└── notes.txt                  # About what?
```

**Result**: Chaos. Can't find anything. Don't know what's current.

### Solution With Routing

```
sessions/session-20251113-150000-api-development/
└── artifacts/
    ├── code/
    │   └── server.js          # ✅ API server for this session
    ├── tests/
    │   └── server.test.js     # ✅ Tests for above server
    ├── docs/
    │   └── API.md             # ✅ Docs for this API
    ├── scripts/
    │   └── deploy.sh          # ✅ Deploys this session's work
    └── notes/
        └── decisions.md       # ✅ Why we made these choices
```

**Result**: Clarity. Everything traceable. Easy to find.

## Routing in Action

### Scenario 1: Full-Stack Development

**Task**: Build authentication system

**Routing**:
```
sessions/session-auth-system/artifacts/
├── code/
│   ├── backend/
│   │   ├── auth.service.js      # Auth business logic
│   │   ├── auth.controller.js   # HTTP handling
│   │   └── auth.repository.js   # Database access
│   ├── frontend/
│   │   ├── LoginForm.jsx        # Login UI
│   │   └── AuthContext.jsx      # Auth state
│   └── database/
│       └── auth.schema.sql      # Database schema
├── tests/
│   ├── backend/
│   │   ├── auth.service.test.js
│   │   └── auth.integration.test.js
│   └── frontend/
│       └── LoginForm.test.jsx
├── docs/
│   ├── auth-flow.md             # How auth works
│   └── security-review.md       # Security considerations
├── scripts/
│   └── setup-auth-db.sh         # Database setup
└── notes/
    ├── jwt-vs-session.md        # Technology decision
    └── implementation-plan.md   # Development roadmap
```

### Scenario 2: Bug Fix Session

**Task**: Fix memory leak in API server

**Routing**:
```
sessions/session-memory-leak-fix/artifacts/
├── code/
│   └── server.js                # Patched server
├── tests/
│   └── memory-leak.test.js      # Regression test
├── docs/
│   └── root-cause.md            # Analysis document
└── notes/
    ├── investigation.md         # Debugging notes
    └── profiling-results.md     # Performance data
```

### Scenario 3: Research Project

**Task**: Evaluate database options

**Routing**:
```
sessions/session-database-research/artifacts/
├── code/
│   ├── prototypes/
│   │   ├── postgres-test.js
│   │   ├── mongodb-test.js
│   │   └── redis-test.js
├── tests/
│   └── benchmark/
│       ├── postgres-perf.test.js
│       └── mongodb-perf.test.js
├── docs/
│   ├── comparison-matrix.md     # Feature comparison
│   └── recommendation.md        # Final choice
└── notes/
    ├── postgres-notes.md        # PostgreSQL findings
    ├── mongodb-notes.md         # MongoDB findings
    └── decision-criteria.md     # How we chose
```

## Exceptions to Routing

### Project Configuration Files

**EXCEPTION**: Project root files stay in place

These files are **NOT routed** to session artifacts:
- `package.json` - NPM dependencies
- `tsconfig.json` - TypeScript config
- `CLAUDE.md` - Workspace config
- `.gitignore` - Git config
- `docker-compose.yml` - Docker config
- Any root-level config files

**Why**: These define the project structure itself, not session artifacts.

**Rule**: Edit these in their original locations, don't copy to session.

### Promoted Artifacts

After session closeout, **some artifacts get promoted** to permanent project locations:

```bash
# After approval, move from session to project
cp sessions/$SESSION_ID/artifacts/docs/API.md docs/projects/api/
cp sessions/$SESSION_ID/artifacts/code/auth/ src/modules/auth/

# Original session artifacts remain for traceability
```

## How Routing is Enforced

### 1. AI Instructions (CLAUDE.md)

Explicit rules in workspace configuration:

```markdown
**File Organization**: ALL working files MUST go to session artifacts:
- sessions/$SESSION_ID/artifacts/code/ - Source code
- sessions/$SESSION_ID/artifacts/tests/ - Tests
- sessions/$SESSION_ID/artifacts/docs/ - Documentation
- sessions/$SESSION_ID/artifacts/scripts/ - Scripts
- sessions/$SESSION_ID/artifacts/notes/ - Notes
```

### 2. File Routing Skill

AI skill at `.claude/skills/file-routing/` provides guidance:

```yaml
metadata:
  name: file-routing
  description: AI self-check for file routing compliance
  capability: verification
```

### 3. Session Initialization

Auto-created directory structure ensures paths exist:

```bash
# Automatically created on session start
mkdir -p "sessions/$SESSION_ID/artifacts"/{code,tests,docs,scripts,notes}
```

## Agent Coordination

When multiple agents work together, routing keeps them organized:

```javascript
// Each agent saves to appropriate subdirectory
Task("Backend Developer",
     "Build API. Save to sessions/$SESSION_ID/artifacts/code/backend/",
     "backend-dev")

Task("Frontend Developer",
     "Build UI. Save to sessions/$SESSION_ID/artifacts/code/frontend/",
     "coder")

Task("Database Architect",
     "Design schema. Save to sessions/$SESSION_ID/artifacts/code/database/",
     "code-analyzer")

Task("Test Engineer",
     "Write tests. Save to sessions/$SESSION_ID/artifacts/tests/",
     "tester")

Task("Documentation Writer",
     "Write docs. Save to sessions/$SESSION_ID/artifacts/docs/",
     "documenter")
```

**Result**: Each agent's work automatically organized by type.

## Verification

### Check Routing Compliance

```bash
# Verify session structure exists
ls -la "sessions/$SESSION_ID/artifacts/"

# Expected output:
# code/
# tests/
# docs/
# scripts/
# notes/

# Check for misplaced files (should be empty)
ls -la tests/      # ❌ Should not contain session files
ls -la docs/       # ❌ Should not contain session files
ls -la scripts/    # ❌ Should not contain session files
```

### Common Violations

```bash
# ❌ WRONG: Writing to root directories
Write "tests/my-test.js"
Write "docs/my-doc.md"
Write "scripts/my-script.sh"

# ✅ CORRECT: Writing to session artifacts
Write "sessions/$SESSION_ID/artifacts/tests/my-test.js"
Write "sessions/$SESSION_ID/artifacts/docs/my-doc.md"
Write "sessions/$SESSION_ID/artifacts/scripts/my-script.sh"
```

## Benefits of File Routing

### 1. Automatic Organization
No manual "where should this go?" decisions. System handles it.

### 2. Traceability
Know exactly which session created which files.

### 3. Clean Workspace
No root-level clutter. Everything in sessions.

### 4. Easy Archival
Entire session directory can be backed up or shared.

### 5. Clear Handoffs
New developer can see complete session context.

### 6. Rollback Safety
Can delete entire session without affecting other work.

## Advanced Patterns

### Multi-Module Projects

```
sessions/session-microservices/artifacts/
├── code/
│   ├── auth-service/
│   │   ├── src/
│   │   └── package.json
│   ├── user-service/
│   │   ├── src/
│   │   └── package.json
│   └── shared/
│       └── types.ts
├── tests/
│   ├── auth-service/
│   ├── user-service/
│   └── integration/
└── docs/
    ├── architecture.md
    └── service-communication.md
```

### Mono-Repo Structure

```
sessions/session-frontend-libs/artifacts/
├── code/
│   ├── packages/
│   │   ├── ui-components/
│   │   ├── utils/
│   │   └── hooks/
│   └── apps/
│       ├── web/
│       └── mobile/
├── tests/
│   └── packages/
│       ├── ui-components/
│       └── utils/
└── docs/
    └── package-apis/
```

## Best Practices

### DO ✅

- Let routing happen automatically
- Use session artifact paths in all agent tasks
- Organize with subdirectories within artifact types
- Keep project configs at root (exceptions)
- Verify routing compliance before session closeout

### DON'T ❌

- Write to root `tests/`, `docs/`, `scripts/` directories
- Create parallel directory structures outside sessions
- Mix session artifacts with project files
- Bypass routing "just this once"
- Delete session artifacts prematurely

## Troubleshooting

**Problem**: Files appearing in wrong location

**Solution**: Check `$SESSION_ID` is set correctly
```bash
echo $SESSION_ID
```

**Problem**: "Directory not found" errors

**Solution**: Initialize session structure
```bash
bash .claude/session/auto-init.sh "topic"
```

**Problem**: Unclear which artifact type to use

**Guideline**:
- Can it be executed? → `code/`
- Does it verify behavior? → `tests/`
- Does it explain? → `docs/`
- Does it automate setup/deployment? → `scripts/`
- Is it rough notes/thoughts? → `notes/`

## Related Documentation

- **Session Management**: [Session Management Explained](session-management.md)
- **File System Details**: [Data Flow (Internals)](../internals/system/data-flow.md)
- **Skill Implementation**: `.claude/skills/file-routing/SKILL.md`

---

**Remember**: Type determines destination. Let the system route for you.
